Mod v1.0.0

this unzipped folder should go into your game files folder, in Steam\steamapps\common\Book of Hours\bh_Data\StreamingAssets\bhcontent\core\
keeping the "zzz_" prefix will allow it to load late, and to properly overwrite the base-game files.